/**
 * The main package, containing the main class GameManager
 * @author Dan Nirel
 */
package danogl;
